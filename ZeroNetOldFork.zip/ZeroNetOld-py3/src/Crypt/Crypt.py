from Config import config
from util import ThreadPool

thread_pool_crypt = ThreadPool.ThreadPool(config.threads_crypt)