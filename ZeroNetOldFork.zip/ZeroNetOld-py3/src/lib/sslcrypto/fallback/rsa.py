# pylint: disable=too-few-public-methods

class RSA:
    def get_backend(self):
        return "fallback"


rsa = RSA()
